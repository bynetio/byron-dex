# plutus-use-cases

Examples of smart contracts with PlutusTx. 
