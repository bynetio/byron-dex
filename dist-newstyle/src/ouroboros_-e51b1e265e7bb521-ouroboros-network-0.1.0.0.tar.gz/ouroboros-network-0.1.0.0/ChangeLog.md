# Revision history for ouroboros-network

## 0.1.0.0 -- 2018-09-20

* Initial experiments and prototyping
