module PlutusIR.Core.Instance () where

import           PlutusIR.Core.Instance.Pretty ()
