module Shelley.Spec.Ledger.Slot
  {-# DEPRECATED "Use 'import Cardano.Ledger.Slot' instead." #-}
  (module X)
where

import Cardano.Ledger.Slot as X
