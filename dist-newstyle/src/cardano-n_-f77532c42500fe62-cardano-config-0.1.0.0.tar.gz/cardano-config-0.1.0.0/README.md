# Cardano Configuration

This package exposes the types and functions necessary to configure the `cardano-node`.
